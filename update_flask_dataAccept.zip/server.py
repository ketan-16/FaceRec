from flask import Flask, request, render_template
import pymongo,os
from werkzeug.utils import secure_filename
from threading import Thread
app=Flask(__name__)

client = pymongo.MongoClient("mongodb+srv://Admin:Ttushar12@cluster0-mqyyp.mongodb.net/test?retryWrites=true&w=majority")
db = client.test
id =0
@app.route('/')
def my_form():
    return render_template('register.html')

@app.route('/', methods=['POST'])
def register():
    global id 
    
    first_name = request.form['first-name']
    middle_name = request.form['middle-name']
    last_name = request.form['last-name']
    branch = request.form['branch']
    aadhar = request.form['aadhar']
    pan = request.form['pan']
    qualification = request.form['qualification']
    designation = request.form['designation']
    phone = request.form['phone']
    email = request.form['email']
    photo = request.files['file']
    photo.save(secure_filename(photo.filename))
    target_filename = first_name+" "+middle_name+" "+last_name+".jpg"
    os.rename(photo.filename,target_filename)
    #move logic
    db.user.insert_one({"id":id,"first_name":first_name,"middle_name":middle_name,"last_name":last_name,"branch":branch,"aadhar":aadhar,"pan":pan,"qualification":qualification, "designation":designation,"phone":phone,"mail":email,"isdeleted":False})
    id+=1
    return render_template('thanks.html')

if __name__ == '__main__':
    app.run(port=5001,debug=True)